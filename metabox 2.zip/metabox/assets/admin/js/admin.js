jQuery(document).ready(function($){
    // Upload first image
    $('#upload_image_button').click(function(e){
        e.preventDefault();
        var imageUploader = wp.media({
            title: 'Select Featured Image',
            button: {
                text: 'Use this image'
            },
            multiple: false
        }).open().on('select', function(){
            var selectedImage = imageUploader.state().get('selection').first().toJSON();
            $('#omb_featured_image').val(selectedImage.url);
            $('#image_preview').html('<img src="' + selectedImage.url + '" style="max-width: 100%; height: auto;" />');
        });
    });

    // Remove first image
    $('#remove_image_button').click(function(e){
        e.preventDefault();
        $('#omb_featured_image').val('');
        $('#image_preview').html('');
    });

    // Upload second image
    $('#upload_second_image_button').click(function(e){
        e.preventDefault();
        var imageUploader = wp.media({
            title: 'Select Second Image',
            button: {
                text: 'Use this image'
            },
            multiple: false
        }).open().on('select', function(){
            var selectedImage = imageUploader.state().get('selection').first().toJSON();
            $('#omb_second_featured_image').val(selectedImage.url);
            $('#second_image_preview').html('<img src="' + selectedImage.url + '" style="max-width: 100%; height: auto;" />');
        });
    });

    // Remove second image
    $('#remove_second_image_button').click(function(e){
        e.preventDefault();
        $('#omb_second_featured_image').val('');
        $('#second_image_preview').html('');
    });
});
