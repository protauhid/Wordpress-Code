<?php
// Start of Our Custom Metabox Class
class OurMetabox {

    public function __construct() {
        add_action( 'plugins_loaded', array( $this, 'omb_load_textdomain' ) );
        add_action( 'admin_menu', array( $this, 'omb_add_metabox' ) );
        add_action( 'save_post', array( $this, 'omb_save_metabox' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'omb_admin_assets' ) );
    }

    // Load plugin textdomain for translations
    public function omb_load_textdomain() {
        load_plugin_textdomain( 'our-metabox', false, dirname( __FILE__ ) . "/languages" );
    }

    // Enqueue admin styles and scripts
    public function omb_admin_assets() {
        wp_enqueue_style( 'omb-admin-style', get_stylesheet_directory_uri() . "/inc/metabox/assets/admin/css/style.css", null, time() );
        wp_enqueue_script( 'omb-admin-script', get_stylesheet_directory_uri() . "/inc/metabox/assets/admin/js/admin.js", array('jquery'), time(), true );
        wp_enqueue_media(); // Make sure to include the media uploader
    }

    // Add Metabox to the post type
    public function omb_add_metabox() {
        add_meta_box(
            'omb_post_location',                     
            __( 'Resources Meta Option', 'our-metabox' ), 
            array( $this, 'omb_display_metabox' ),    
            array( 'post' ),                    
            'side',                                  
            'low'                                    
        );
    }

    // Display Metabox HTML
    public function omb_display_metabox( $post ) {
        // Get saved meta values
        $location      = get_post_meta( $post->ID, 'omb_location', true );
        $author        = get_post_meta( $post->ID, 'omb_author', true );
        $btntext       = get_post_meta( $post->ID, 'omb_btntext', true );
        $btnlink       = get_post_meta( $post->ID, 'omb_btnlink', true );
        $is_new_window = get_post_meta( $post->ID, 'omb_is_new_window', true );
        $image_url     = get_post_meta( $post->ID, 'omb_featured_image', true ); // First image
        $second_image_url = get_post_meta( $post->ID, 'omb_second_featured_image', true ); // Second image

        $checked = $is_new_window ? 'checked' : '';

        // Security nonce
        wp_nonce_field( 'omb_location', 'omb_location_field' );

        // Metabox form fields
        ?>
        <p><span class="note">All options will apply after Save or Publish.</span></p>

        <p>
            <label for="omb_author"><?php _e( 'Author Name', 'our-metabox' ); ?>:</label>
            <input type="text" name="omb_author" id="omb_author" value="<?php echo esc_attr( $author ); ?>" />
        </p>

        <p>
            <label for="omb_btntext"><?php _e( 'Button Text', 'our-metabox' ); ?>:</label>
            <input type="text" name="omb_btntext" id="omb_btntext" value="<?php echo esc_attr( $btntext ); ?>" />
        </p>

        <p>
            <label for="omb_btnlink"><?php _e( 'Button Link', 'our-metabox' ); ?>:</label>
            <input type="text" name="omb_btnlink" id="omb_btnlink" value="<?php echo esc_attr( $btnlink ); ?>" />
        </p>

        <p>
            <label for="omb_is_new_window"><?php _e( 'Open in New Window', 'our-metabox' ); ?>:</label>
            <input type="checkbox" name="omb_is_new_window" id="omb_is_new_window" value="1" <?php echo $checked; ?> />
        </p>

        <hr />

        <p>
            <label for="omb_location"><?php _e( 'Featured Image Size', 'our-metabox' ); ?>:</label>
            <input type="text" name="omb_location" id="omb_location" value="<?php echo esc_attr( $location ); ?>" />
            <small>Example: featured-blog (800px x 430px), thumbnail, medium, etc.</small>
        </p>

        <hr />

        <!-- First Image Upload Section -->
        <p>
            <label for="omb_featured_image"><?php _e( 'Upload Featured Image', 'our-metabox' ); ?>:</label>
            <input type="hidden" id="omb_featured_image" name="omb_featured_image" value="<?php echo esc_attr( $image_url ); ?>" />
            <div id="image_preview">
                <?php if ( $image_url ) : ?>
                    <img src="<?php echo esc_url( $image_url ); ?>" alt="Featured Image" style="max-width: 100%; height: auto;" />
                    <br><a href="#" id="remove_image_button">Remove Image</a>
                <?php endif; ?>
            </div>
            <button type="button" id="upload_image_button" class="button"><?php _e( 'Upload Image', 'our-metabox' ); ?></button>
        </p>

        <hr />

        <!-- Second Image Upload Section -->
        <p>
            <label for="omb_second_featured_image"><?php _e( 'Upload Second Image', 'our-metabox' ); ?>:</label>
            <input type="hidden" id="omb_second_featured_image" name="omb_second_featured_image" value="<?php echo esc_attr( $second_image_url ); ?>" />
            <div id="second_image_preview">
                <?php if ( $second_image_url ) : ?>
                    <img src="<?php echo esc_url( $second_image_url ); ?>" alt="Second Featured Image" style="max-width: 100%; height: auto;" />
                    <br><a href="#" id="remove_second_image_button">Remove Image</a>
                <?php endif; ?>
            </div>
            <button type="button" id="upload_second_image_button" class="button"><?php _e( 'Upload Second Image', 'our-metabox' ); ?></button>
        </p>
        <?php
    }

    // Save Metabox Fields
    public function omb_save_metabox( $post_id ) {
        // Check nonce and user capabilities
        if ( ! $this->is_secured( 'omb_location_field', 'omb_location', $post_id ) ) {
            return $post_id;
        }

        // Define fields to save
        $fields = [
            'omb_author',
            'omb_btntext',
            'omb_btnlink',
        ];

        // Save each field
        foreach ( $fields as $field ) {
            if ( isset( $_POST[$field] ) ) {
                update_post_meta( $post_id, $field, sanitize_text_field( $_POST[$field] ) );
            }
        }

        // Save checkbox separately
        $is_new_window = isset( $_POST['omb_is_new_window'] ) ? 1 : 0;
        update_post_meta( $post_id, 'omb_is_new_window', $is_new_window );

        // Handle the first image
        if ( isset( $_POST['omb_featured_image'] ) ) {
            $image_url = esc_url_raw( $_POST['omb_featured_image'] );

            if ( ! empty( $image_url ) ) {
                update_post_meta( $post_id, 'omb_featured_image', $image_url );
            } else {
                delete_post_meta( $post_id, 'omb_featured_image' );
            }
        }

        // Handle the second image
        if ( isset( $_POST['omb_second_featured_image'] ) ) {
            $second_image_url = esc_url_raw( $_POST['omb_second_featured_image'] );

            if ( ! empty( $second_image_url ) ) {
                update_post_meta( $post_id, 'omb_second_featured_image', $second_image_url );
            } else {
                delete_post_meta( $post_id, 'omb_second_featured_image' );
            }
        }
    }

    // Security Checks: nonce, permissions, autosave
    private function is_secured( $nonce_field, $action, $post_id ) {
        $nonce = isset( $_POST[ $nonce_field ] ) ? $_POST[ $nonce_field ] : '';

        if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, $action ) ) {
            return false;
        }

        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return false;
        }

        return true;
    }
}

// Initialize the class
new OurMetabox();
?>
